package com.lanshare.cam;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

/**
 * تطبيق بسيط: يفتح صفحة "كاميرا -> الكمبيوتر" الخاصة ببرنامج LanShareOCR
 * ويدعم التصوير بالكاميرا واختيار الصور من المعرض داخل الصفحة.
 */
public class MainActivity extends Activity {

    private static final int REQ_FILE = 1;
    private static final int MENU_CHANGE = 1;
    private static final int MENU_RELOAD = 2;

    private WebView web;
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;
    private boolean errorShowing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    showError();
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                return openChooser(callback, params);
            }
        });

        loadSaved();
    }

    // ------------------------------------------------------------ الاتصال

    private void loadSaved() {
        String url = prefs.getString("url", "");
        if (url.isEmpty()) {
            askAddress();
        } else {
            web.loadUrl(url);
        }
    }

    private void askAddress() {
        final boolean hasSaved = !prefs.getString("url", "").isEmpty();

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);

        final EditText addr = new EditText(this);
        addr.setHint("رابط الموبايل  أو  192.168.1.5:8000");
        addr.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        addr.setSingleLine(true);
        addr.setText(prefs.getString("raw", ""));

        final EditText pin = new EditText(this);
        pin.setHint("رمز PIN (لو مش موجود داخل الرابط)");
        pin.setInputType(InputType.TYPE_CLASS_NUMBER);
        pin.setSingleLine(true);

        box.addView(addr);
        box.addView(pin);

        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("عنوان الكمبيوتر")
                .setMessage("انسخ PHONE LINK من نافذة البرنامج على الكمبيوتر والصقه هنا")
                .setView(box)
                .setCancelable(hasSaved)
                .setPositiveButton("اتصال", (d, w) ->
                        connect(addr.getText().toString(), pin.getText().toString()));
        if (hasSaved) {
            b.setNegativeButton("إلغاء", null);
        }
        b.show();
    }

    private void connect(String raw, String pinText) {
        raw = raw.trim();
        pinText = pinText.trim();
        if (raw.isEmpty()) {
            Toast.makeText(this, "اكتب عنوان الكمبيوتر", Toast.LENGTH_SHORT).show();
            askAddress();
            return;
        }
        String full = raw;
        if (!full.startsWith("http://") && !full.startsWith("https://")) {
            full = "http://" + full;
        }
        Uri u = Uri.parse(full);
        String host = u.getHost();
        if (host == null || host.isEmpty()) {
            Toast.makeText(this, "العنوان غير صحيح", Toast.LENGTH_SHORT).show();
            askAddress();
            return;
        }
        int port = u.getPort() == -1 ? 8000 : u.getPort();
        String pin = u.getQueryParameter("pin");
        if (pin == null || pin.isEmpty()) {
            pin = pinText;
        }
        String url = "http://" + host + ":" + port + "/phone";
        if (!pin.isEmpty()) {
            url += "?pin=" + Uri.encode(pin);
        }
        prefs.edit().putString("url", url).putString("raw", raw).apply();
        web.loadUrl(url);
    }

    private void showError() {
        if (errorShowing) {
            return;
        }
        errorShowing = true;
        new AlertDialog.Builder(this)
                .setTitle("تعذّر الاتصال بالكمبيوتر")
                .setMessage("تأكد أن البرنامج شغّال على الكمبيوتر وأن الموبايل على نفس الواي فاي.")
                .setPositiveButton("إعادة المحاولة", (d, w) -> {
                    errorShowing = false;
                    loadSaved();
                })
                .setNegativeButton("تغيير العنوان", (d, w) -> {
                    errorShowing = false;
                    askAddress();
                })
                .setOnCancelListener(d -> errorShowing = false)
                .show();
    }

    // ------------------------------------------------------------ الكاميرا / المعرض

    private boolean openChooser(ValueCallback<Uri[]> callback, WebChromeClient.FileChooserParams params) {
        if (fileCallback != null) {
            fileCallback.onReceiveValue(null);
        }
        fileCallback = callback;
        cameraUri = null;

        Intent camera = null;
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "scan_" + System.currentTimeMillis() + ".jpg");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LanShareCam");
            cameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (cameraUri != null) {
                camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
                camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            }
        } catch (Exception e) {
            cameraUri = null;
            camera = null;
        }

        Intent toLaunch;
        if (params.isCaptureEnabled() && camera != null) {
            // الصفحة طلبت الكاميرا مباشرة
            toLaunch = camera;
        } else {
            Intent gallery = new Intent(Intent.ACTION_GET_CONTENT);
            gallery.addCategory(Intent.CATEGORY_OPENABLE);
            gallery.setType("image/*");
            if (params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE) {
                gallery.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            }
            toLaunch = Intent.createChooser(gallery, "اختر الصورة");
            if (camera != null) {
                toLaunch.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
            }
        }

        try {
            startActivityForResult(toLaunch, REQ_FILE);
        } catch (Exception e) {
            finishChooser(null);
            Toast.makeText(this, "تعذّر فتح الكاميرا", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != REQ_FILE) {
            super.onActivityResult(requestCode, resultCode, data);
            return;
        }
        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                result = new Uri[n];
                for (int i = 0; i < n; i++) {
                    result[i] = data.getClipData().getItemAt(i).getUri();
                }
            } else if (data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            } else if (cameraUri != null) {
                result = new Uri[]{cameraUri};
            }
        }
        finishChooser(result);
    }

    private void finishChooser(Uri[] result) {
        boolean usedCamera = result != null && cameraUri != null
                && result.length == 1 && cameraUri.equals(result[0]);
        if (cameraUri != null && !usedCamera) {
            try {
                getContentResolver().delete(cameraUri, null, null);
            } catch (Exception ignored) {
            }
        }
        cameraUri = null;
        if (fileCallback != null) {
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    // ------------------------------------------------------------ القائمة

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, MENU_RELOAD, 0, "تحديث");
        menu.add(0, MENU_CHANGE, 1, "تغيير عنوان الكمبيوتر");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == MENU_CHANGE) {
            askAddress();
            return true;
        }
        if (item.getItemId() == MENU_RELOAD) {
            loadSaved();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}
